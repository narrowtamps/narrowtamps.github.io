# Neon Signs
A demo of neon flickering letters, using box-shadow for the neon effect and JavaScript to randomly select the letters. Keyframes make the letters flicker in a seemingly random pattern. The demo contains several text examples like those old neon signs you would see on the side of the road. This project is build using my own [New Game](https://github.com/markteekman/new-game) Gulp Build (feel free to use it!).

[Checkout the live demo here.](https://markteekman.nl/levelup/neon-signs/)

[Checkout my other LEVELUP projects here.](https://markteekman.nl/levelup/)

![og-level-neon-signs](https://user-images.githubusercontent.com/3909046/113411470-22140380-93b6-11eb-926f-63727989be7f.jpg)
